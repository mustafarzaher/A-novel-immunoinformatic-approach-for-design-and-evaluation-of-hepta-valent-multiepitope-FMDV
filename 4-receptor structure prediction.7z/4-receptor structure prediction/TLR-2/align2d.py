from modeller import *

env = Environ()
aln = Alignment(env)
mdl = Model(env, file='2z80', model_segment=('FIRST:A','LAST:A'))
aln.append_model(mdl, align_codes='2z80A', atom_files='2z80.pdb')
aln.append(file='queryseq.ali', align_codes='queryseq')
aln.align2d(max_gap_length=50)
aln.write(file='queryseq-2z80A.ali', alignment_format='PIR')
aln.write(file='queryseq-2z80A.pap', alignment_format='PAP')