from modeller import *

env = Environ()
aln = Alignment(env)
mdl = Model(env, file='4g8a', model_segment=('FIRST:A','LAST:A'))
aln.append_model(mdl, align_codes='4g8aA', atom_files='4g8a.pdb')
aln.append(file='queryseq.ali', align_codes='queryseq')
aln.align2d(max_gap_length=50)
aln.write(file='queryseq-4g8aA.ali', alignment_format='PIR')
aln.write(file='queryseq-4g8aA.pap', alignment_format='PAP')